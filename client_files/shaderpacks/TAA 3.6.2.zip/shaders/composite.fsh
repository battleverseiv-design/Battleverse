#version 120

#include "/settings.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D depthtex0;      
uniform sampler2D dhDepthTex0;   
uniform sampler2D dhDepthTex1;    

uniform int heightLimit;

uniform mat4 dhProjectionInverse;
uniform mat4 dhProjection;
uniform mat4 gbufferProjection; 
uniform mat4 gbufferModelViewInverse; 

uniform vec3 cameraPosition; 
uniform float viewWidth;
uniform float viewHeight;
uniform float dhNearPlane;
uniform float dhFarPlane;
uniform int dhRenderDistance;     
uniform int frameCounter;

varying vec4 color;
varying vec2 coord0;

const bool colortex2Clear = false;
const vec2 sampleKernel[12] = vec2[12](
    vec2(0.2343, 0.8765), vec2(-0.5432, 0.3456), vec2(0.7654, -0.2341),
    vec2(-0.3214, -0.7632), vec2(0.5678, 0.4321), vec2(-0.8765, -0.1234),
    vec2(0.1234, -0.5678), vec2(-0.6543, 0.7654), vec2(0.8765, 0.1234),
    vec2(-0.2345, -0.4567), vec2(0.4567, -0.8765), vec2(-0.7654, 0.5432)
);

float hash(vec2 p) {
    p = fract(p * 0.3183099 + 0.1);
    p *= 17.0;
    return fract(p.x * p.y * (p.x + p.y));
}

float linearizeDepth(float depth, float near, float far) {
    return (2.0 * near * far) / (far + near - depth * (far - near));
}

vec3 getViewPosition(vec2 uv, float depth) {
    vec4 clipSpace = vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec4 viewSpace = dhProjectionInverse * clipSpace;
    return viewSpace.xyz / viewSpace.w;
}

vec3 reconstructNormal(vec2 uv, float depth) {
    vec2 pixelSize = vec2(1.0 / viewWidth, 1.0 / viewHeight);
    
    // Sample all 4 directions
    float depthR = texture2D(dhDepthTex0, uv + vec2(pixelSize.x, 0.0)).r;
    float depthL = texture2D(dhDepthTex0, uv - vec2(pixelSize.x, 0.0)).r;
    float depthU = texture2D(dhDepthTex0, uv + vec2(0.0, pixelSize.y)).r;
    float depthD = texture2D(dhDepthTex0, uv - vec2(0.0, pixelSize.y)).r;

    // Find absolute depth differences
    float diffR = abs(depthR - depth);
    float diffL = abs(depthL - depth);
    float diffU = abs(depthU - depth);
    float diffD = abs(depthD - depth);

    // Pick the samples with the smallest depth difference to avoid grabbing the background
    float bestDepthX = diffR < diffL ? depthR : depthL;
    float bestDepthY = diffU < diffD ? depthU : depthD;
    
    float offsetX = diffR < diffL ? pixelSize.x : -pixelSize.x;
    float offsetY = diffU < diffD ? pixelSize.y : -pixelSize.y;

    vec3 posC = getViewPosition(uv, depth);
    vec3 posX = getViewPosition(uv + vec2(offsetX, 0.0), bestDepthX);
    vec3 posY = getViewPosition(uv + vec2(0.0, offsetY), bestDepthY);
    
    // Ensure vectors point in the correct direction depending on which side we picked
    vec3 dx = diffR < diffL ? posX - posC : posC - posX;
    vec3 dy = diffU < diffD ? posY - posC : posC - posY;
    
    return normalize(cross(dx, dy));
}
vec2 rotate2D(vec2 v, float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return vec2(v.x * c - v.y * s, v.x * s + v.y * c);
}

float calculateSSAO(vec2 uv, float depth, vec3 viewPos, float worldDist) {
    vec3 position = getViewPosition(uv, depth);
    vec3 normal = reconstructNormal(uv, depth);

    float fovY = 2.0 * atan(1.0 / gbufferProjection[1][1]);
    float fovY_degrees = degrees(fovY);

    float logScale = log2(worldDist/(20.0*16.0)); 
    float radius = SSAO_RADIUS + 2.0 * max(logScale+max(fovY_degrees-110.0,0.0)*0.005,0.0);
    float intensity = 0.05 + max(SSAO_INTENSITY - worldDist * 0.0004, 0.25);
    
    vec2 noiseCoord = uv * vec2(viewWidth, viewHeight);
    float noise = hash(noiseCoord * 0.1 + float(frameCounter % 64) * 0.01);
    float noiseAngle = noise * 6.28318;
    
    vec3 randomVec = normalize(vec3(noise * 2.0 - 1.0, hash(noiseCoord * 0.37) * 2.0 - 1.0, 0.0));
    vec3 tangent = normalize(randomVec - normal * dot(randomVec, normal));
    vec3 bitangent = cross(normal, tangent);
    mat3 TBN = mat3(tangent, bitangent, normal);
    
    float occlusion = 0.0;
    
    // Dynamic Bias (Fix 2)
    float dynamicBias = SSAO_BIAS * max(1.0, radius * 0.5);
    
    for (int i = 0; i < SSAO_SAMPLES; i++) {
        vec2 rotatedSample = rotate2D(sampleKernel[i], noiseAngle);
        
        float scale = float(i + 1) / 12.0;
        vec3 sampleOffset = vec3(rotatedSample * scale, scale * 0.6); 
        
        sampleOffset = TBN * normalize(sampleOffset);
        vec3 samplePos = position + sampleOffset * radius;
        
        vec4 offset = dhProjection * vec4(samplePos, 1.0);
        offset.xyz /= offset.w;
        offset.xy = offset.xy * 0.5 + 0.5;
        
        // If it goes off-screen, skip adding to occlusion, but we will still divide by the total sample count later
        if (offset.x < 0.0 || offset.x > 1.0 || offset.y < 0.0 || offset.y > 1.0) {
            continue;
        }
        
        float sampleDepth = texture2D(dhDepthTex0, offset.xy).r;
        if (sampleDepth >= 1.0) continue;
        
        vec3 sampleViewPos = getViewPosition(offset.xy, sampleDepth);
        
        float distZ = abs(position.z - sampleViewPos.z);
        float rangeCheck = smoothstep(0.0, 1.0, radius / (distZ + 0.001));
        
        float delta = sampleViewPos.z - samplePos.z;
        
        occlusion += (delta >= dynamicBias ? 1.0 : 0.0) * rangeCheck;
    }
    
    // Divide by the constant SSAO_SAMPLES instead of a shrinking validSamples counter
    occlusion = 1.0 - (occlusion / float(SSAO_SAMPLES));
    
    return pow(occlusion, intensity);
}

void main()
{
    float temporalData = 0.0;
    vec3 temporalColor = texture2D(colortex2, coord0).rgb;
    
    vec3 baseColor = (color * texture2D(colortex0, coord0)).rgb;
    
    float regularDepth = texture2D(depthtex0, coord0).r;
    float dhDepth = texture2D(dhDepthTex0, coord0).r;
    vec4 infotex = texture2D(colortex3, coord0);
    
    float ao = 1.0;
    
    if (dhDepth < 1.0 && regularDepth >= 1.0 && SSAO_SAMPLES != 0 && infotex.r != 1){
        vec3 viewPos = getViewPosition(coord0, dhDepth);
        vec4 worldPos = gbufferModelViewInverse * vec4(viewPos, 1.0);
        float worldHeight = worldPos.y + cameraPosition.y;

        // True 3D Euclidean world-space distance from camera
        float worldDist = length(worldPos.xyz);

        if (worldHeight <= heightLimit) {
            ao = calculateSSAO(coord0, dhDepth, viewPos, worldDist);
            
            ao = mix(ao, 1.0, infotex.a);
        }
    }
    
    vec3 finalColor = baseColor * ao;

    /*DRAWBUFFERS:12*/
    gl_FragData[0] = vec4(finalColor, 1.0);
    gl_FragData[1] = vec4(temporalColor, temporalData);
}